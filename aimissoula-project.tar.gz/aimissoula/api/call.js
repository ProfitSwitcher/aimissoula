// Vercel Serverless Function — triggers AI phone call via Vapi.ai
// Required env vars in Vercel:
//   VAPI_API_KEY         — your Vapi private key (dashboard.vapi.ai → Organization → API Keys)
//   VAPI_PHONE_NUMBER_ID — your Vapi phone number ID (Phone Numbers tab)
//
// Optional:
//   VAPI_ASSISTANT_ID    — if you have a saved assistant, use it instead of the transient one below

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { phone, name, business } = req.body || {};

  if (!phone || !name) {
    return res.status(400).json({ error: "Phone and name are required" });
  }

  const VAPI_API_KEY = process.env.VAPI_API_KEY;
  const VAPI_PHONE_NUMBER_ID = process.env.VAPI_PHONE_NUMBER_ID;
  const VAPI_ASSISTANT_ID = process.env.VAPI_ASSISTANT_ID;

  if (!VAPI_API_KEY) {
    return res.status(500).json({ error: "Vapi API key not configured" });
  }
  if (!VAPI_PHONE_NUMBER_ID) {
    return res.status(500).json({ error: "Vapi phone number ID not configured" });
  }

  // Clean phone number to E.164 format
  let cleanPhone = phone.replace(/[^0-9+]/g, "");
  if (!cleanPhone.startsWith("+")) {
    cleanPhone = cleanPhone.startsWith("1") ? `+${cleanPhone}` : `+1${cleanPhone}`;
  }

  // Build the request body
  const callBody = {
    phoneNumberId: VAPI_PHONE_NUMBER_ID,
    customer: {
      number: cleanPhone,
      name: name,
    },
    name: `Website Demo — ${name}${business ? ` (${business})` : ""}`,
  };

  // Use saved assistant if configured, otherwise use transient assistant
  if (VAPI_ASSISTANT_ID) {
    callBody.assistantId = VAPI_ASSISTANT_ID;
    callBody.assistantOverrides = {
      firstMessage: `Hi ${name}! This is the AI assistant from AI Missoula. You just hit the demo button on our website — pretty cool that I'm calling you right now, right?`,
      variableValues: {
        customerName: name,
        customerBusiness: business || "their business",
      },
    };
  } else {
    // Transient assistant — fully configured inline
    callBody.assistant = {
      name: "AI Missoula Demo Agent",
      firstMessage: `Hi ${name}! This is the AI assistant from AI Missoula. You just hit the demo button on our website — pretty cool that I'm calling you right now, right?`,
      firstMessageMode: "assistant-speaks-first",
      model: {
        provider: "anthropic",
        model: "claude-sonnet-4-20250514",
        temperature: 0.7,
        messages: [
          {
            role: "system",
            content: `You are an AI phone assistant demo calling on behalf of AI Missoula, an AI automation agency based in Missoula, Montana.

You are calling ${name}${business ? ` from ${business}` : ""}. They just requested a live demo from the AI Missoula website to experience what an AI phone assistant can do for their business.

Your goals:
1. After your greeting, briefly explain what you are: "I'm an example of the kind of AI phone system we build for businesses. I can answer questions, book appointments, qualify leads, and handle customer calls — all without a human on the line."
2. Ask about their business: "So tell me a little about your business — what do you do, and what's eating up most of your time right now?"
3. Listen and suggest 1-2 specific AI solutions that could help them based on what they share.
4. Offer to connect them with the AI Missoula team: "I'd love to have our team follow up with some specific recommendations. Would a quick call or email from them work better for you?"
5. If they give a preference, confirm it and wrap up: "Perfect, I'll make sure they reach out. Thanks for taking this call ${name} — this is just a taste of what we can set up for your business. Have a great day!"

Keep it conversational, friendly, and under 3 minutes. You're demonstrating the product by BEING the product. If they ask pricing, say it varies by project but consultations with the team are always free.

IMPORTANT: Never say you are Claude, GPT, or any other AI model name. You are simply the AI Missoula phone assistant.`,
          },
        ],
      },
      voice: {
        provider: "11labs",
        voiceId: "burt",
      },
      maxDurationSeconds: 180,
      endCallMessage: "Thanks for checking out AI Missoula! We'll be in touch soon. Bye!",
      endCallPhrases: ["goodbye", "bye", "that's all", "end call"],
      metadata: {
        source: "aimissoula.com",
        leadName: name,
        leadPhone: cleanPhone,
        leadBusiness: business || "not provided",
      },
    };
  }

  try {
    const response = await fetch("https://api.vapi.ai/call", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${VAPI_API_KEY}`,
      },
      body: JSON.stringify(callBody),
    });

    const data = await response.json();

    if (response.status === 201 || response.ok) {
      return res.status(200).json({
        success: true,
        message: `Call initiated to ${cleanPhone}`,
        callId: data.id,
      });
    } else {
      console.error("Vapi error:", data);
      return res.status(response.status).json({
        error: "Failed to initiate call",
        details: data.message || data,
      });
    }
  } catch (err) {
    console.error("Call API error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
}
